import java.util.Scanner;

public class JavaWait {
	public static void main(String[] args) {
		System.out.println("Press enter to quit");
		Scanner s = new Scanner(System.in);
		String x = s.nextLine();
	}
}
