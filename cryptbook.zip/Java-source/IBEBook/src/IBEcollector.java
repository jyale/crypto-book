/**
 * Used to collect public keys from keyservers and encrypt a message
 * 
 * @author John
 * 
 */
public class IBEcollector {
	
}
