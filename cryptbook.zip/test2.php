<?php
// outputs the username that owns the running php/httpd process
// (on a system with the "whoami" executable in the path)
echo("test<br>");
echo exec('../../../usr/java/jdk1.6/bin/java Test');
echo("<br>test");
?>
